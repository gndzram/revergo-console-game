﻿using System;
namespace ReverGo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "ReverGo";
            Menu menu = new Menu();
            int gamecode;
            //gamecode 
            //11 --> (16 x 1) & (player vs AI)
            //12 --> (8 x 8) & (player vs AI)
            //21 --> (16 x 1) & (player vs player)
            //22 --> (8 x 8) & (player vs player)
            //-1 exit game
            while (true)
            {
                gamecode = menu.menuScreen();
                if (gamecode == -1) break;
                if ((gamecode % 10) == 1)
                {
                    Table16 gameboard = new Table16();
                    gameboard.game(gamecode / 10);
                }
                else
                {
                    Table8 gameboard = new Table8();
                    gameboard.game(gamecode / 10);
                }
            }
            return;
        }
    }
    class Table16
    {
        private const int safeAreaStarts = 5;
        private const int safeAreaEnds = 13;
        private const int stonesRow = 3;
        private const int row = 5;
        private const int col = 18;
        private int round;
        private char[][] table;
        private char player1 = 'O';
        private char player2 = 'X';
        private char empty = '.';
        private string[] playerNames = null;
        public Table16()
        {
            initialize();
        }
        private void initialize()
        {
            table = new char[row][];
            for (int i = 0; i < row; i++)
            {
                table[i] = new char[col];
            }
            string str = " 0000000001111111 ";
            table[0] = str.ToCharArray();
            str = " 1234567890123456 ";
            table[1] = str.ToCharArray();
            str = "+----------------+";
            table[2] = str.ToCharArray();
            table[4] = str.ToCharArray();
            str = "|................|";
            table[3] = str.ToCharArray();
        }
        private void toScreen()
        {
            for (int i = 0; i < row; i++)
            {
                Console.WriteLine(table[i]);
            }
            Console.SetCursorPosition(20, 2);
            Console.WriteLine("Round  :{0}", round);
            Console.SetCursorPosition(20, 3);
            Console.WriteLine("{0}  :{1}", playerNames[0], countStones(player1, table[stonesRow]));
            Console.SetCursorPosition(20, 4);
            Console.WriteLine("{0}  :{1}", playerNames[1], countStones(player2, table[stonesRow]));
        }
        public void game(int gamecode)//if gamecode=1 --> player vs AI , else player vs player
        {
            round = 0;
            playerNames = new string[2];
            if (gamecode == 1)
            {
                Console.Clear();
                Console.Write("\nPlease enter your name:");
                playerNames[0] = Console.ReadLine();
                if (playerNames[0].Length == 0) playerNames[0] = "Player";
                playerNames[1] = "Computer";
                while (true)
                {
                    Console.Clear();
                    toScreen();
                    Console.SetCursorPosition(0, 7);
                    Console.WriteLine("({1}) {0}'s turn", playerNames[0], player1);
                    int place = move(player1);
                    if (place == -1) return;
                    round++;
                    checkNchange(player1, place, table[stonesRow]);
                    Console.Clear();
                    toScreen();
                    Console.SetCursorPosition(0, 7);
                    Console.WriteLine("({1}) {0}'s turn", playerNames[1], player2);
                    place = AI();//AI plays
                    System.Threading.Thread.Sleep(500);
                    round++;
                    int isFinished = checkNchange(player2, place, table[stonesRow]);
                    if (isFinished == 1) break;//if game over naturally

                    Console.SetCursorPosition(place, stonesRow + 2);
                    Console.Write((char)24);
                    Console.SetCursorPosition(place, stonesRow);

                    System.Threading.Thread.Sleep(1000);
                    
                    Console.SetCursorPosition(place, stonesRow + 2);
                    Console.Write(' ');
                }
            }
            else
            {
                Console.Clear();
                Console.Write("\nPlease enter 1. player name:");
                playerNames[0] = Console.ReadLine();
                if (playerNames[0].Length == 0) playerNames[0] = "1. Player";
                Console.Write("\nPlease enter 2. player name:");
                playerNames[1] = Console.ReadLine();
                if (playerNames[1].Length == 0) playerNames[1] = "2. Player";
                while (true)
                {
                    Console.Clear();
                    toScreen();
                    Console.SetCursorPosition(0, 7);
                    Console.WriteLine("({1}) {0}'s turn", playerNames[0], player1);
                    int place = move(player1);
                    if (place == -1) return;
                    round++;
                    checkNchange(player1, place, table[stonesRow]);
                    Console.Clear();
                    toScreen();
                    Console.SetCursorPosition(0, 7);
                    Console.WriteLine("({1}) {0}'s turn", playerNames[1], player2);
                    place = move(player2);
                    if (place == -1) return;
                    round++;
                    int isFinished = checkNchange(player2, place, table[stonesRow]);
                    if (isFinished == 1) break;//if game over naturally
                }
            }
            Console.Clear();
            toScreen();
            Console.SetCursorPosition(0, 7);
            Console.WriteLine("Game Over\n");
            if (countStones(player1, table[stonesRow]) == 8) Console.WriteLine("No winner. It is draw.");
            else if (countStones(player1, table[stonesRow]) < 8) Console.WriteLine("{0} won the game.", playerNames[1]);
            else Console.WriteLine("{0} won the game.", playerNames[0]);
            Console.SetCursorPosition(0, 0);
            Console.ReadKey();
            return;
        }
        private int move(char player)
        {
            int selection = 1;
            while (true)
            {
                Console.SetCursorPosition(selection, stonesRow + 2);
                Console.Write((char)24);
                Console.SetCursorPosition(selection, stonesRow);

                System.ConsoleKeyInfo key = Console.ReadKey(true);

                Console.SetCursorPosition(selection, stonesRow + 2);
                Console.Write(' ');

                if (System.ConsoleKey.Enter.Equals(key.Key))
                {
                    if (isValidPlace(selection, table[stonesRow]))
                    {
                        table[stonesRow][selection] = player;
                        return selection;
                    }
                    else if (table[stonesRow][selection] == empty)
                    {
                        Console.SetCursorPosition(0, 9);
                        Console.WriteLine("You have to select a valid place!!           ");
                    }
                    else
                    {
                        Console.SetCursorPosition(0, 9);
                        Console.WriteLine("The place you have selected is already full!!");
                    }
                }
                else if (System.ConsoleKey.LeftArrow.Equals(key.Key) && selection > 1) selection--;
                else if (System.ConsoleKey.RightArrow.Equals(key.Key) && selection < 16) selection++;
                else if (System.ConsoleKey.Escape.Equals(key.Key))
                {
                    Console.Clear();
                    Console.WriteLine("\nAre you sure to give up!\n");
                    string[] options = new string[2];
                    options[0] = " YES";
                    options[1] = " NO";
                    int a = Menu.select(5, options);
                    if (a == 1) return -1;
                    else
                    {
                        Console.Clear();
                        toScreen();
                        Console.SetCursorPosition(0, 7);
                        if (player == player1) Console.WriteLine("({1}){0}'s turn", playerNames[0], player1);
                        else Console.WriteLine("({1}){0}'s turn", playerNames[1], player2);
                    }
                }
            }
        }
        private int checkNchange(char player, int place, char[] table)//if game over returns 1 else returns 0
        {
            int look = place;
            while (look > 0)
            {
                look--;
                if (table[look] == table[place])
                {
                    while (look < place)
                    {
                        look++;
                        table[look] = player;
                    }
                    break;
                }
                else if (table[look] == empty)
                {
                    break;
                }
            }
            look = place;
            while (look < table.Length - 1)
            {
                look++;
                if (table[look] == table[place])
                {
                    while (look > place)
                    {
                        look--;
                        table[look] = player;
                    }
                    break;
                }
                else if (table[look] == empty)
                {
                    break;
                }
            }
            for (int i = 1; i < table.Length - 1; i++)
            {
                if (table[i] == empty) return 0;
            }
            return 1;//returns 1 if there is no place left
        }
        private int countStones(char player, char[] table)
        {
            int count = 0;
            for (int i = 0; i < table.Length; i++)
                if (table[i] == player) count++;
            return count;
        }
        private bool isValidPlace(int place, char[] table)
        {
            bool isValid = false;
            if (table[place] == empty)
            {
                if (place < safeAreaStarts)
                {
                    if (table[place + 1] != empty || table[place + 2] != empty)
                    {
                        isValid = true;
                    }
                }
                else if (place >= safeAreaEnds)
                {
                    if (table[place - 1] != empty || table[place - 2] != empty)
                    {
                        isValid = true;
                    }
                }
                else isValid = true;
            }
            return isValid;
        }
        private int AI()
        {
            char[] thisTable1 = new char[table[stonesRow].Length];
            char[] thisTable2 = new char[table[stonesRow].Length];
            int minGain;
            int bestGain = 0;
            int bestPlace = 0;
            int[] checkList = { 1, 16, 4, 13, 5, 12, 6, 11, 7, 10, 8, 9, 3, 14, 2, 15 };
            for (int k = 0; k < 16; k++)
            {
                int i = checkList[k];
                table[stonesRow].CopyTo(thisTable1, 0);
                if (isValidPlace(i, thisTable1))
                {
                    thisTable1[i] = player2;
                    if (checkNchange(player2, i, thisTable1) == 1)//if game over then return the place
                    {                                            //change func. is called once, no need to call again
                        break;
                    }
                    minGain = int.MaxValue;
                    for (int j = 1; j < thisTable2.Length - 1; j++)
                    {
                        thisTable1.CopyTo(thisTable2, 0);
                        if (isValidPlace(j, thisTable2))
                        {
                            thisTable2[j] = player1;
                            checkNchange(player1, j, thisTable2);
                            if (minGain > countStones(player2, thisTable2))
                            {
                                minGain = countStones(player2, thisTable2);
                            }
                        }
                    }
                    if (bestGain < minGain)
                    {
                        bestPlace = i;
                        bestGain = minGain;
                    }
                }
            }
            if (bestPlace == 0)
            {
                Random rand = new Random();
                while (true)
                {
                    bestPlace = rand.Next(16) + 1;
                    if (isValidPlace(bestPlace, table[stonesRow]))
                    {
                        break;
                    }
                }
            }
            table[stonesRow][bestPlace] = player2;
            return bestPlace;
        }
    }
    class Table8
    {
        private const int row = 11;
        private const int col = 20;
        private const int verticalArrowsPosition = 12;//the vertical arrow moves in horizontal
        private const int horizontalArrowsPosition = 21;//the horizontal arrow moves in vertical
        private const int safeArea1 = 3;
        private const int safeArea2 = 7;
        private int round;
        private char[][] table;
        private char player1 = 'O';
        private char player2 = 'X';
        private char empty = '.';
        private string[] playerNames = null;
        public Table8()
        {
            initialize();
        }
        private void initialize()
        {
            table = new char[row][];
            for (int i = 0; i < row; i++)
            {
                table[i] = new char[col];
            }
            string str = "+ - - - - - - - - +";
            table[0] = str.ToCharArray();
            table[9] = str.ToCharArray();
            str = "  1 2 3 4 5 6 7 8";
            table[10] = str.ToCharArray();
            str = "| . . . . . . . . | ";
            for (int i = 1; i <= 8; i++)
            {
                table[i] = str.ToCharArray();
                table[i][col - 1] = (char)(i + '0');
            }
        }
        private void toScreen()
        {
            Console.WriteLine("   1 2 3 4 5 6 7 8");
            for (int i = 0; i < row; i++)
            {
                if (i < 9 && i > 0) Console.Write("{0}", (char)(i + '0'));
                else Console.Write(" ");
                Console.WriteLine(table[i]);
            }
            Console.SetCursorPosition(23, 2);
            Console.WriteLine("Round  :{0}", round);
            Console.SetCursorPosition(23, 3);
            Console.WriteLine("{0}  :{1}", playerNames[0], countStones(player1, table));
            Console.SetCursorPosition(23, 4);
            Console.WriteLine("{0}  :{1}", playerNames[1], countStones(player2, table));
        }
        public void game(int gamecode)
        {
            round = 0;
            playerNames = new string[2];
            if (gamecode == 1)
            {
                Console.Clear();
                Console.Write("\nPlease enter your name:");
                playerNames[0] = Console.ReadLine();
                if (playerNames[0].Length == 0) playerNames[0] = "Player";
                playerNames[1] = "Computer";
                while (true)
                {
                    Console.Clear();
                    toScreen();
                    Console.SetCursorPosition(0, 14);
                    Console.WriteLine("({1}) {0}'s turn", playerNames[0], player1);
                    int[] place = move(player1);
                    if (place[0] == -1) return;
                    round++;
                    checkNchange(player1, place, table);
                    Console.Clear();
                    toScreen();
                    Console.SetCursorPosition(0, 14);
                    Console.WriteLine("({1}) {0}'s turn", playerNames[1], player2);
                    place = AI();//AI plays
                    System.Threading.Thread.Sleep(500);
                    round++;
                    int isFinished = checkNchange(player2, place, table);
                    if (isFinished == 1) break;//if game over naturally

                    Console.SetCursorPosition(horizontalArrowsPosition, place[0] + 1);
                    Console.Write((char)27);
                    Console.SetCursorPosition(place[1] * 2 + 1, verticalArrowsPosition);
                    Console.Write((char)24);
                    Console.SetCursorPosition(place[1] * 2 + 1, place[0] + 1);

                    System.Threading.Thread.Sleep(1000);
                    

                    Console.SetCursorPosition(horizontalArrowsPosition, place[0] + 1);
                    Console.Write(' ');
                    Console.SetCursorPosition(place[1] * 2 + 1, verticalArrowsPosition);
                    Console.Write(' ');
                }
            }
            else
            {
                Console.Clear();
                Console.Write("\nPlease enter 1. player name:");
                playerNames[0] = Console.ReadLine();
                if (playerNames[0].Length == 0) playerNames[0] = "1. Player";
                Console.Write("\nPlease enter 2. player name:");
                playerNames[1] = Console.ReadLine();
                if (playerNames[1].Length == 0) playerNames[1] = "2. Player";
                while (true)
                {
                    Console.Clear();
                    toScreen();
                    Console.SetCursorPosition(0, 14);
                    Console.WriteLine("({1}) {0}'s turn", playerNames[0], player1);
                    int[] place = move(player1);
                    if (place[0] == -1) return;
                    round++;
                    checkNchange(player1, place, table);
                    Console.Clear();
                    toScreen();
                    Console.SetCursorPosition(0, 14);
                    Console.WriteLine("({1}) {0}'s turn", playerNames[1], player2);
                    place = move(player2);
                    if (place[0] == -1) return;
                    round++;
                    int isFinished = checkNchange(player2, place, table);
                    if (isFinished == 1) break;//if game over naturally
                }
            }
            Console.Clear();
            toScreen();
            Console.SetCursorPosition(0, 13);
            Console.WriteLine("Game Over\n");
            if (countStones(player1, table) == 32) Console.WriteLine("No winner. It is draw.");
            else if (countStones(player1, table) < 32) Console.WriteLine("{0} won the game.", playerNames[1]);
            else Console.WriteLine("{0} won the game.", playerNames[0]);
            Console.SetCursorPosition(0, 0);
            Console.ReadKey();
            return;
        }
        private int[] move(char player)
        {
            int[] selection = new int[2];
            selection[0] = 1;
            selection[1] = 1;
            while (true)
            {
                Console.SetCursorPosition(horizontalArrowsPosition, selection[0] + 1);
                Console.Write((char)27);
                Console.SetCursorPosition(selection[1] * 2 + 1, verticalArrowsPosition);
                Console.Write((char)24);
                Console.SetCursorPosition(selection[1] * 2 + 1, selection[0] + 1);

                System.ConsoleKeyInfo key = Console.ReadKey(true);

                Console.SetCursorPosition(horizontalArrowsPosition, selection[0] + 1);
                Console.Write(' ');
                Console.SetCursorPosition(selection[1] * 2 + 1, verticalArrowsPosition);
                Console.Write(' ');

                if (System.ConsoleKey.Enter.Equals(key.Key))
                {
                    if (isValidPlace(selection, table))
                    {
                        table[selection[0]][selection[1] * 2] = player;
                        return selection;
                    }
                    else if (table[selection[0]][selection[1] * 2] == empty)
                    {
                        Console.SetCursorPosition(0, 16);
                        Console.WriteLine("You have to select a valid place!!           ");
                    }
                    else
                    {
                        Console.SetCursorPosition(0, 16);
                        Console.WriteLine("The place you have selected is already full!!");
                    }
                }
                else if (System.ConsoleKey.LeftArrow.Equals(key.Key) && selection[1] > 1) selection[1]--;
                else if (System.ConsoleKey.RightArrow.Equals(key.Key) && selection[1] < 8) selection[1]++;
                else if (System.ConsoleKey.UpArrow.Equals(key.Key) && selection[0] > 1) selection[0]--;
                else if (System.ConsoleKey.DownArrow.Equals(key.Key) && selection[0] < 8) selection[0]++;
                else if (System.ConsoleKey.Escape.Equals(key.Key))
                {
                    Console.Clear();
                    Console.WriteLine("\nAre you sure to give up!\n");
                    string[] options = new string[2];
                    options[0] = " YES";
                    options[1] = " NO";
                    int a = Menu.select(5, options);

                    if (a == 1)
                    {
                        selection[0] = -1;
                        return selection;
                    }
                    else
                    {
                        Console.Clear();
                        toScreen();
                        Console.SetCursorPosition(0, 14);
                        if (player == player1) Console.WriteLine("({1}) {0}'s turn", playerNames[0], player1);
                        else Console.WriteLine("({1}) {0}'s turn", playerNames[1], player2);
                    }
                }
            }
        }
        private int checkNchange(char player, int[] place, char[][] table)
        {
            int[] way = new int[2];
            int[] look = new int[2];
            for (int i = 1; i < 9; i++)
            {
                for (int j = 1; j < 9; j++)
                {
                    if ((table[i][j * 2] != empty) && ((Math.Abs(place[0] - i)) < 2) && ((Math.Abs(place[1] - j)) < 2))
                    {
                        way[0] = i - place[0];
                        way[1] = j - place[1];
                        look[0] = place[0];
                        look[1] = place[1];
                        while (look[0] > 0 && look[1] > 0 && look[0] < 9 && look[1] < 9)
                        {
                            look[0] += way[0];
                            look[1] += way[1];
                            if (table[look[0]][look[1] * 2] == player)
                            {
                                while (!(look[0] == place[0] && look[1] == place[1]))
                                {
                                    look[0] -= way[0];
                                    look[1] -= way[1];
                                    table[look[0]][look[1] * 2] = player;
                                }
                                break;
                            }
                            else if (table[look[0]][look[1] * 2] == empty)
                            {
                                break;
                            }
                        }
                    }
                }
            }

            for (int i = 1; i < 9; i++)
            {
                for (int j = 1; j < 9; j++)
                    if (table[i][j * 2] == empty) return 0;
            }
            return 1; //returns 1 if there is no empty place
        }
        private bool isValidPlace(int[] place, char[][] table)
        {
            bool isValid = false;
            if (table[place[0]][place[1] * 2] == empty)
            {
                if (place[0] < safeArea1 || place[0] >= safeArea2 || place[1] < safeArea1 || place[1] >= safeArea2)
                {
                    for (int i = 1; i <= 8; i++)
                    {
                        for (int j = 1; j <= 8; j++)
                        {
                            if ((table[i][j * 2] != empty) && ((Math.Abs(place[0] - i)) < 3) && ((Math.Abs(place[1] - j)) < 3))
                            {
                                isValid = true;
                            }
                        }
                    }
                }
                else isValid = true;
            }
            return isValid;
        }
        private int countStones(char player, char[][] table)
        {
            int count = 0;
            for (int i = 0; i < table.Length; i++)
                for (int j = 0; j < table[i].Length; j++)
                    if (table[i][j] == player) count++;
            return count;
        }
        private int[] AI()
        {
            char[][] thisTable1 = new char[table.Length][];//each array for each deepth level
            char[][] thisTable2 = new char[table.Length][];
            char[][] thisTable3 = new char[table.Length][];
            for (int i = 0; i < table.Length; i++)
            {
                thisTable1[i] = new char[table[i].Length];
                thisTable2[i] = new char[table[i].Length];
                thisTable3[i] = new char[table[i].Length];
            }
            int minGain;
            int bestGain = 0;
            int[] bestPlace = new int[2];
            bestPlace[0] = 0;
            int[] selection = new int[2];
            int bonus = 0;//add priority to edges

            int[,] checkList ={{1,1},{1,8},{8,1},{8,8},{1,4},{4,8},{8,5},{5,1},
                              {1,5},{5,8},{8,4},{4,1},{2,4},{4,7},{7,5},{5,2},
                              {2,5},{5,7},{7,4},{4,2},{3,4},{4,6},{6,5},{5,3},
                              {3,5},{5,6},{6,4},{4,3},{4,4},{5,5},{4,5},{5,4},
                              {1,2},{2,8},{8,7},{7,1},{1,3},{3,8},{8,6},{6,1},
                              {2,1},{1,7},{7,8},{8,2},{2,2},{2,7},{7,7},{7,2},
                              {2,3},{3,7},{7,6},{6,2},{2,6},{6,7},{7,3},{3,2},
                              {3,1},{1,6},{6,8},{8,3},{3,3},{3,6},{6,6},{6,3}};

            for (int a = 0; a < 64; a++)
            {
                if (a < 4) bonus = 3;
                else if (a >= 32) bonus = -2;//this places make opponent able to put stone on edge
                else bonus = 0;
                int i = checkList[a, 0];
                int j = checkList[a, 1];
                for (int k = 0; k < thisTable1.Length; k++)
                {
                    table[k].CopyTo(thisTable1[k], 0);
                }
                selection[0] = i;
                selection[1] = j;
                if (isValidPlace(selection, thisTable1))
                {
                    thisTable1[selection[0]][selection[1] * 2] = player2;
                    if (checkNchange(player2, selection, thisTable1) == 1)//if game over then return the place
                    {                                            //change func. is called once, no need to call again
                        break;
                    }
                    minGain = int.MaxValue;
                    for (int l = 0; l < 9; l++)
                    {
                        for (int m = 0; m < 9; m++)
                        {
                            for (int k = 0; k < thisTable2.Length; k++)
                            {
                                thisTable1[k].CopyTo(thisTable2[k], 0);
                            }
                            int[] selection2 = new int[2];
                            selection2[0] = l;
                            selection2[1] = m;
                            if (isValidPlace(selection2, thisTable2))
                            {
                                thisTable2[selection2[0]][selection2[1] * 2] = player1;
                                checkNchange(player1, selection2, thisTable2);
                                for (int b = 0; b < 9; b++)
                                {
                                    for (int c = 0; c < 9; c++)
                                    {
                                        for (int k = 0; k < thisTable2.Length; k++)
                                        {
                                            thisTable2[k].CopyTo(thisTable3[k], 0);
                                        }
                                        int[] selection3 = new int[2];
                                        selection3[0] = b;
                                        selection3[1] = c;
                                        if (isValidPlace(selection3, thisTable3))
                                        {
                                            thisTable3[selection3[0]][selection3[1] * 2] = player2;
                                            checkNchange(player2, selection3, thisTable3);
                                            int result = countStones(player2, thisTable3) + bonus;
                                            if (minGain > result)
                                            {
                                                minGain = result;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (bestGain < minGain)
                    {
                        bestPlace[0] = i;
                        bestPlace[1] = j;
                        bestGain = minGain;
                    }
                }
            }
            if (bestPlace[0] == 0 || bestPlace[1] == 0)
            {
                Random rand = new Random();
                while (true)
                {
                    bestPlace[0] = rand.Next(8) + 1;
                    bestPlace[1] = rand.Next(8) + 1;
                    if (isValidPlace(bestPlace, table))
                    {
                        break;
                    }
                }
            }
            table[bestPlace[0]][bestPlace[1] * 2] = player2;
            return bestPlace;
        }
    }
    class Menu
    {
        string[] gameScreen = null;
        string[] options = null;
        public Menu()
        {
            gameScreen = new string[3];
            gameScreen[0] = "                   *********************************";
            gameScreen[1] = "     ***************      Wellcome to ReverGo      ***************";
            gameScreen[2] = "                   *********************************";
        }
        public int menuScreen()
        {
            int gamecode = 0;
            int optionsStarts = 5;//seçenek başlangıç satırı
            while (true)
            {
                options = new string[3];
                options[0] = " Play";
                options[1] = " About us";
                options[2] = " Exit";
                printGameName();
                int selectedRow = select(optionsStarts, options);
                if (selectedRow == 1)
                {
                    while (true)
                    {
                        options[0] = " Play with computer";
                        options[1] = " Play with human";
                        options[2] = " Back";
                        printGameName();
                        selectedRow = select(optionsStarts, options);
                        if (selectedRow != 3)
                        {
                            gamecode = 10 * selectedRow;
                            options[0] = " 1 x 16";
                            options[1] = " 8 x 8";
                            options[2] = " Back";
                            printGameName();
                            selectedRow = select(optionsStarts, options);
                            if (selectedRow == 3) gamecode = 0;
                            else return gamecode + selectedRow;
                        }
                        else break;
                    }
                }
                else if (selectedRow == 2)
                {
                    options = new string[1];
                    options[0] = " Back";
                    printGameName();
                    Console.WriteLine(" About us");
                    Console.WriteLine("     Ramazan Gündüz          2013510114");
                    Console.WriteLine("     Ozan Biber              2012510012");
                    Console.WriteLine("     Doğukan Hazar Çaktu     2014510103");
                    select(8, options);
                }
                else return -1;
            }
        }
        public static int select(int optionsStarts, string[] options)
        {
            int selection = 0;
            int numberOfSelections = options.Length;
            Console.SetCursorPosition(0, optionsStarts);

            for (int i = 0; i < options.Length; i++)
            {
                Console.WriteLine(options[i]);
            }

            while (true)
            {
                Console.SetCursorPosition(0, selection + optionsStarts);
                Console.Write((char)26);
                Console.SetCursorPosition(0, 0);

                System.ConsoleKeyInfo key = Console.ReadKey(true);

                Console.SetCursorPosition(0, selection + optionsStarts);
                Console.Write(' ');

                if (System.ConsoleKey.Enter.Equals(key.Key)) return selection + 1;
                else if (System.ConsoleKey.UpArrow.Equals(key.Key) && selection > 0) selection--;
                else if (System.ConsoleKey.DownArrow.Equals(key.Key) && selection < numberOfSelections - 1) selection++;
            }
        }
        private void printGameName()
        {
            Console.Clear();
            for (int i = 0; i < gameScreen.Length; i++)
            {
                Console.WriteLine(gameScreen[i]);
            }
        }
    }
}
